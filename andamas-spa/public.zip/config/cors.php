<?php
return [
    'paths' => [
        'api/*',
        'login',
        'logout',
        'sanctum/csrf-cookie'
    ],
    'supports_credentials' => true,
];