<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Pedidos</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <div id="app"></div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\scraping-shein\andamas-spa\resources\views/app.blade.php ENDPATH**/ ?>